﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeManagement
{
    public partial class EmployeeManagement : MetroFramework.Forms.MetroForm
    {
        public EmployeeManagement()
        {
            InitializeComponent();
        }

        private void metroButtonAddEmp_Click(object sender, EventArgs e)
        {
            var empName = metroTextBoxEmpName.Text;
            var empEmail = metroTextBoxEmpEmail.Text;
            var empAddress = metroTextBoxEmpAddress.Text;
            var empAge = metroTextBoxEmpAge.Text;
            int empAgeInt;
            bool isNumericAge = int.TryParse(empAge, out empAgeInt);

            bool IsValidEmail(string strIn)
            {
                // Return true if strIn is in valid e-mail format.
                return Regex.IsMatch(strIn, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
            }

            if (empName=="" || empAddress=="" || empAge=="" || empEmail=="")
            {
                htmlLabelMessageBox.Text = "Fill All Fields!";
            }
            else if (!isNumericAge)
            {
                htmlLabelMessageBox.Text = "Age must be a Number";
            }else if (!IsValidEmail(empEmail))
            {
                htmlLabelMessageBox.Text = "Enter A Valid Email Address";
            }
            else
            {
                using (employeesEntities context = new employeesEntities())
                {


                    Employee newEmp = new Employee
                    {
                        Employee_Name = empName,
                        Employee_Address = empAddress,
                        Email_Address = empEmail,
                        Age = empAgeInt
                    };
                    context.Employees.Add(newEmp);
                    context.SaveChanges();

                }

            }


        }
    }
}
