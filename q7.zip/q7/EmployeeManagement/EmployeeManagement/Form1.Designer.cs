﻿namespace EmployeeManagement
{
    partial class EmployeeManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabelEmpName = new MetroFramework.Controls.MetroLabel();
            this.metroButtonAddEmp = new MetroFramework.Controls.MetroButton();
            this.metroLabelEmail = new MetroFramework.Controls.MetroLabel();
            this.metroTextBoxEmpEmail = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBoxEmpAddress = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTextBoxEmpAge = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBoxEmpName = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabelMessageBox = new MetroFramework.Drawing.Html.HtmlLabel();
            this.SuspendLayout();
            // 
            // metroLabelEmpName
            // 
            this.metroLabelEmpName.AutoSize = true;
            this.metroLabelEmpName.Location = new System.Drawing.Point(37, 81);
            this.metroLabelEmpName.Name = "metroLabelEmpName";
            this.metroLabelEmpName.Size = new System.Drawing.Size(110, 19);
            this.metroLabelEmpName.TabIndex = 2;
            this.metroLabelEmpName.Text = "Employee Name:";
            // 
            // metroButtonAddEmp
            // 
            this.metroButtonAddEmp.Location = new System.Drawing.Point(300, 243);
            this.metroButtonAddEmp.Name = "metroButtonAddEmp";
            this.metroButtonAddEmp.Size = new System.Drawing.Size(110, 23);
            this.metroButtonAddEmp.TabIndex = 3;
            this.metroButtonAddEmp.Text = "Add Employee";
            this.metroButtonAddEmp.UseSelectable = true;
            this.metroButtonAddEmp.Click += new System.EventHandler(this.metroButtonAddEmp_Click);
            // 
            // metroLabelEmail
            // 
            this.metroLabelEmail.AutoSize = true;
            this.metroLabelEmail.Location = new System.Drawing.Point(37, 110);
            this.metroLabelEmail.Name = "metroLabelEmail";
            this.metroLabelEmail.Size = new System.Drawing.Size(106, 19);
            this.metroLabelEmail.TabIndex = 5;
            this.metroLabelEmail.Text = "Employee Email:";
            // 
            // metroTextBoxEmpEmail
            // 
            // 
            // 
            // 
            this.metroTextBoxEmpEmail.CustomButton.Image = null;
            this.metroTextBoxEmpEmail.CustomButton.Location = new System.Drawing.Point(224, 1);
            this.metroTextBoxEmpEmail.CustomButton.Name = "";
            this.metroTextBoxEmpEmail.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBoxEmpEmail.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBoxEmpEmail.CustomButton.TabIndex = 1;
            this.metroTextBoxEmpEmail.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBoxEmpEmail.CustomButton.UseSelectable = true;
            this.metroTextBoxEmpEmail.CustomButton.Visible = false;
            this.metroTextBoxEmpEmail.Lines = new string[0];
            this.metroTextBoxEmpEmail.Location = new System.Drawing.Point(164, 110);
            this.metroTextBoxEmpEmail.MaxLength = 32767;
            this.metroTextBoxEmpEmail.Name = "metroTextBoxEmpEmail";
            this.metroTextBoxEmpEmail.PasswordChar = '\0';
            this.metroTextBoxEmpEmail.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBoxEmpEmail.SelectedText = "";
            this.metroTextBoxEmpEmail.SelectionLength = 0;
            this.metroTextBoxEmpEmail.SelectionStart = 0;
            this.metroTextBoxEmpEmail.ShortcutsEnabled = true;
            this.metroTextBoxEmpEmail.Size = new System.Drawing.Size(246, 23);
            this.metroTextBoxEmpEmail.TabIndex = 4;
            this.metroTextBoxEmpEmail.UseSelectable = true;
            this.metroTextBoxEmpEmail.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBoxEmpEmail.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(37, 139);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(121, 19);
            this.metroLabel2.TabIndex = 7;
            this.metroLabel2.Text = "Employee Address:";
            // 
            // metroTextBoxEmpAddress
            // 
            // 
            // 
            // 
            this.metroTextBoxEmpAddress.CustomButton.Image = null;
            this.metroTextBoxEmpAddress.CustomButton.Location = new System.Drawing.Point(190, 2);
            this.metroTextBoxEmpAddress.CustomButton.Name = "";
            this.metroTextBoxEmpAddress.CustomButton.Size = new System.Drawing.Size(53, 53);
            this.metroTextBoxEmpAddress.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBoxEmpAddress.CustomButton.TabIndex = 1;
            this.metroTextBoxEmpAddress.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBoxEmpAddress.CustomButton.UseSelectable = true;
            this.metroTextBoxEmpAddress.CustomButton.Visible = false;
            this.metroTextBoxEmpAddress.Lines = new string[0];
            this.metroTextBoxEmpAddress.Location = new System.Drawing.Point(164, 139);
            this.metroTextBoxEmpAddress.MaxLength = 32767;
            this.metroTextBoxEmpAddress.Multiline = true;
            this.metroTextBoxEmpAddress.Name = "metroTextBoxEmpAddress";
            this.metroTextBoxEmpAddress.PasswordChar = '\0';
            this.metroTextBoxEmpAddress.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBoxEmpAddress.SelectedText = "";
            this.metroTextBoxEmpAddress.SelectionLength = 0;
            this.metroTextBoxEmpAddress.SelectionStart = 0;
            this.metroTextBoxEmpAddress.ShortcutsEnabled = true;
            this.metroTextBoxEmpAddress.Size = new System.Drawing.Size(246, 58);
            this.metroTextBoxEmpAddress.TabIndex = 6;
            this.metroTextBoxEmpAddress.UseSelectable = true;
            this.metroTextBoxEmpAddress.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBoxEmpAddress.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(37, 203);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(102, 19);
            this.metroLabel1.TabIndex = 9;
            this.metroLabel1.Text = "Employee Age: ";
            // 
            // metroTextBoxEmpAge
            // 
            // 
            // 
            // 
            this.metroTextBoxEmpAge.CustomButton.Image = null;
            this.metroTextBoxEmpAge.CustomButton.Location = new System.Drawing.Point(224, 1);
            this.metroTextBoxEmpAge.CustomButton.Name = "";
            this.metroTextBoxEmpAge.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBoxEmpAge.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBoxEmpAge.CustomButton.TabIndex = 1;
            this.metroTextBoxEmpAge.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBoxEmpAge.CustomButton.UseSelectable = true;
            this.metroTextBoxEmpAge.CustomButton.Visible = false;
            this.metroTextBoxEmpAge.Lines = new string[0];
            this.metroTextBoxEmpAge.Location = new System.Drawing.Point(164, 203);
            this.metroTextBoxEmpAge.MaxLength = 32767;
            this.metroTextBoxEmpAge.Name = "metroTextBoxEmpAge";
            this.metroTextBoxEmpAge.PasswordChar = '\0';
            this.metroTextBoxEmpAge.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBoxEmpAge.SelectedText = "";
            this.metroTextBoxEmpAge.SelectionLength = 0;
            this.metroTextBoxEmpAge.SelectionStart = 0;
            this.metroTextBoxEmpAge.ShortcutsEnabled = true;
            this.metroTextBoxEmpAge.Size = new System.Drawing.Size(246, 23);
            this.metroTextBoxEmpAge.TabIndex = 8;
            this.metroTextBoxEmpAge.UseSelectable = true;
            this.metroTextBoxEmpAge.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBoxEmpAge.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBoxEmpName
            // 
            // 
            // 
            // 
            this.metroTextBoxEmpName.CustomButton.Image = null;
            this.metroTextBoxEmpName.CustomButton.Location = new System.Drawing.Point(224, 1);
            this.metroTextBoxEmpName.CustomButton.Name = "";
            this.metroTextBoxEmpName.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBoxEmpName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBoxEmpName.CustomButton.TabIndex = 1;
            this.metroTextBoxEmpName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBoxEmpName.CustomButton.UseSelectable = true;
            this.metroTextBoxEmpName.CustomButton.Visible = false;
            this.metroTextBoxEmpName.Lines = new string[0];
            this.metroTextBoxEmpName.Location = new System.Drawing.Point(164, 81);
            this.metroTextBoxEmpName.MaxLength = 32767;
            this.metroTextBoxEmpName.Name = "metroTextBoxEmpName";
            this.metroTextBoxEmpName.PasswordChar = '\0';
            this.metroTextBoxEmpName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBoxEmpName.SelectedText = "";
            this.metroTextBoxEmpName.SelectionLength = 0;
            this.metroTextBoxEmpName.SelectionStart = 0;
            this.metroTextBoxEmpName.ShortcutsEnabled = true;
            this.metroTextBoxEmpName.Size = new System.Drawing.Size(246, 23);
            this.metroTextBoxEmpName.TabIndex = 10;
            this.metroTextBoxEmpName.UseSelectable = true;
            this.metroTextBoxEmpName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBoxEmpName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // htmlLabelMessageBox
            // 
            this.htmlLabelMessageBox.AutoScroll = true;
            this.htmlLabelMessageBox.AutoScrollMinSize = new System.Drawing.Size(74, 23);
            this.htmlLabelMessageBox.AutoSize = false;
            this.htmlLabelMessageBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.htmlLabelMessageBox.Location = new System.Drawing.Point(37, 243);
            this.htmlLabelMessageBox.Name = "htmlLabelMessageBox";
            this.htmlLabelMessageBox.Size = new System.Drawing.Size(204, 23);
            this.htmlLabelMessageBox.TabIndex = 11;
            this.htmlLabelMessageBox.Text = "MessageBox";
            // 
            // EmployeeManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 286);
            this.Controls.Add(this.htmlLabelMessageBox);
            this.Controls.Add(this.metroTextBoxEmpName);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroTextBoxEmpAge);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroTextBoxEmpAddress);
            this.Controls.Add(this.metroLabelEmail);
            this.Controls.Add(this.metroTextBoxEmpEmail);
            this.Controls.Add(this.metroButtonAddEmp);
            this.Controls.Add(this.metroLabelEmpName);
            this.Name = "EmployeeManagement";
            this.Text = "EmployeeManagement";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroLabel metroLabelEmpName;
        private MetroFramework.Controls.MetroButton metroButtonAddEmp;
        private MetroFramework.Controls.MetroLabel metroLabelEmail;
        private MetroFramework.Controls.MetroTextBox metroTextBoxEmpEmail;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox metroTextBoxEmpAddress;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox metroTextBoxEmpAge;
        private MetroFramework.Controls.MetroTextBox metroTextBoxEmpName;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabelMessageBox;
    }
}

